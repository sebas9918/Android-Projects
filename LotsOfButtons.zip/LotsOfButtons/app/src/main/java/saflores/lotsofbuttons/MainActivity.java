package saflores.lotsofbuttons;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private Button bulldogButton;
    private Button centipedeButton;
    private Button cockButton;
    private Button eagleButton;
    private Button elephantButton;
    private Button frogButton;
    private Button giraffeButton;
    private Button ladybugButton;
    private Button moleButton;
    private Button pandabearButton;
    private Button pigButton;
    private Button platypusButton;
    private Button seaurchinButton;
    private Button sharkButton;
    private Button slothButton;
    private Button squidButton;
    private ImageView animalImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bulldogButton = findViewById(R.id.bulldog_button);
        centipedeButton = findViewById(R.id.centipede_button);
        cockButton = findViewById(R.id.cock_button);
        eagleButton = findViewById(R.id.eagle_button);
        elephantButton = findViewById(R.id.elephant_button);
        frogButton = findViewById(R.id.frog_button);
        giraffeButton = findViewById(R.id.giraffe_button);
        ladybugButton = findViewById(R.id.ladybug_button);
        moleButton = findViewById(R.id.mole_button);
        pandabearButton = findViewById(R.id.pandabear_button);
        pigButton = findViewById(R.id.pig_button);
        platypusButton = findViewById(R.id.platypus_button);
        seaurchinButton = findViewById(R.id.seaurchin_button);
        sharkButton = findViewById(R.id.shark_button);
        slothButton = findViewById(R.id.sloth_button);
        squidButton = findViewById(R.id.squid_button);
        animalImage = findViewById(R.id.animal_image);


    }
    public void bulldogClick(View view) {
        animalImage.setImageResource(R.drawable.bulldog);
    }
    public void centipedeClick(View view) {
        animalImage.setImageResource(R.drawable.centipede);
    }
    public void cockClick(View view) {
        animalImage.setImageResource(R.drawable.cock);
    }
    public void eagleClick(View view) {
        animalImage.setImageResource(R.drawable.eagle);
    }
    public void elephantClick(View view) {
        animalImage.setImageResource(R.drawable.elephant);
    }
    public void frogClick(View view) {
        animalImage.setImageResource(R.drawable.frog);
    }
    public void giraffeClick(View view) {
        animalImage.setImageResource(R.drawable.giraffe);
    }
    public void ladybugClick(View view) {
        animalImage.setImageResource(R.drawable.ladybug);
    }
    public void moleClick(View view) {
        animalImage.setImageResource(R.drawable.mole);
    }
    public void pandabearClick(View view) {
        animalImage.setImageResource(R.drawable.pandabear);
    }
    public void pigClick(View view) {
        animalImage.setImageResource(R.drawable.pig);
    }
    public void platypusClick(View view) {
        animalImage.setImageResource(R.drawable.platypus);
    }
    public void seaurchinClick(View view) {
        animalImage.setImageResource(R.drawable.seaurchin);
    }
    public void sharkClick(View view) {
        animalImage.setImageResource(R.drawable.shark);
    }
    public void slothClick(View view) {
        animalImage.setImageResource(R.drawable.sloth);
    }
    public void squidClick(View view) {
        animalImage.setImageResource(R.drawable.squid);
    }
}
